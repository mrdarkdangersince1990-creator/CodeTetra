import type { Metadata } from 'next';
import '../styles/globals.css';

export const metadata: Metadata = {
  title: 'CodeTetra — Build Intelligence, Not Infrastructure',
  description: 'Enterprise AI infrastructure. GPU clusters, custom server builds, and hyperscale deployments tailored for the intelligence economy.',
  keywords: ['AI infrastructure', 'GPU servers', 'data center', 'machine learning', 'enterprise AI'],
  openGraph: {
    title: 'CodeTetra — Build Intelligence, Not Infrastructure',
    description: 'Enterprise AI infrastructure for the intelligence economy.',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className="noise-overlay bg-ct-black antialiased">
        {children}
      </body>
    </html>
  );
}
