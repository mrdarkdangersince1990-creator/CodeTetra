'use client';

import dynamic from 'next/dynamic';
import { useEffect, useRef, useState } from 'react';
import Navigation from '@/components/Navigation';
import HeroSection from '@/components/sections/HeroSection';
import GPUBreakdownSection from '@/components/sections/GPUBreakdownSection';
import ServerBuilderSection from '@/components/sections/ServerBuilderSection';
import ClusterSection from '@/components/sections/ClusterSection';
import PricingSection from '@/components/sections/PricingSection';
import RoadmapSection from '@/components/sections/RoadmapSection';
import FounderSection from '@/components/sections/FounderSection';
import FinalCTASection from '@/components/sections/FinalCTASection';
import CustomCursor from '@/components/ui/CustomCursor';
import LoadingScreen from '@/components/ui/LoadingScreen';

const SceneCanvas = dynamic(() => import('@/components/3d/SceneCanvas'), {
  ssr: false,
  loading: () => null,
});

export default function Home() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 2800);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const total = document.documentElement.scrollHeight - window.innerHeight;
      setScrollProgress(window.scrollY / total);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      {!isLoaded && <LoadingScreen />}
      <CustomCursor />

      {/* Fixed 3D Canvas background */}
      <div className="canvas-container">
        <SceneCanvas scrollProgress={scrollProgress} />
      </div>

      {/* Fixed Navigation */}
      <Navigation />

      {/* Scroll Progress Bar */}
      <div className="fixed top-0 left-0 w-full h-px z-50">
        <div
          className="h-full bg-gradient-to-r from-ct-cyan via-ct-blue to-ct-green transition-all duration-100"
          style={{ width: `${scrollProgress * 100}%` }}
        />
      </div>

      {/* Scrollable Content */}
      <main ref={mainRef} className="relative z-10">
        <HeroSection />
        <GPUBreakdownSection />
        <ServerBuilderSection />
        <ClusterSection />
        <PricingSection />
        <RoadmapSection />
        <FounderSection />
        <FinalCTASection />
      </main>
    </>
  );
}
