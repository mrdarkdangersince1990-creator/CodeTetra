'use client';

export default function FounderSection() {
  return (
    <section id="founder" className="relative min-h-screen flex items-center py-32">
      <div className="absolute inset-0 bg-gradient-to-b from-ct-black/90 to-ct-dark/80 pointer-events-none" />

      {/* Decorative corner elements */}
      <div className="absolute top-16 left-6 w-16 h-16 border-t border-l border-ct-cyan/20" />
      <div className="absolute top-16 right-6 w-16 h-16 border-t border-r border-ct-cyan/20" />
      <div className="absolute bottom-16 left-6 w-16 h-16 border-b border-l border-ct-cyan/20" />
      <div className="absolute bottom-16 right-6 w-16 h-16 border-b border-r border-ct-cyan/20" />

      <div className="max-w-[1400px] mx-auto px-6 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: founder card */}
          <div className="flex flex-col items-start gap-8">
            {/* Avatar placeholder */}
            <div className="relative">
              <div
                className="w-32 h-32 clip-corner-lg flex items-center justify-center relative overflow-hidden"
                style={{
                  background: 'linear-gradient(135deg, #0D1117 0%, #1A2332 100%)',
                  border: '1px solid rgba(0,212,255,0.3)',
                }}
              >
                {/* Initials */}
                <span className="font-display text-4xl font-black text-ct-cyan">AS</span>

                {/* Corner decoration */}
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-ct-cyan to-ct-blue" />
              </div>

              {/* Online indicator */}
              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-ct-dark border-2 border-ct-dark flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-ct-green animate-pulse" />
              </div>
            </div>

            {/* Name block */}
            <div className="space-y-2">
              <div className="font-mono text-[10px] text-ct-gray tracking-[0.3em] uppercase">
                Founder & CEO
              </div>
              <h2 className="font-display text-4xl lg:text-5xl font-black text-white leading-tight">
                ANIKET
                <br />
                <span className="text-ct-cyan">SHARMA</span>
              </h2>
              <div className="font-mono text-[11px] text-ct-gray tracking-widest">
                aka <span className="text-ct-cyan">Andyy</span>
              </div>
            </div>

            {/* Contact */}
            <a
              href="mailto:as977100@gmail.com"
              className="btn-primary text-[10px] py-3 px-6"
            >
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <rect x="1" y="3" width="12" height="8" rx="1" stroke="currentColor" strokeWidth="1" />
                <path d="M1 4L7 8L13 4" stroke="currentColor" strokeWidth="1" />
              </svg>
              as977100@gmail.com
            </a>

            {/* Social links */}
            <div className="flex gap-4">
              {[
                { label: 'LinkedIn', icon: 'in' },
                { label: 'Twitter', icon: 'X' },
                { label: 'GitHub', icon: 'GH' },
              ].map((s) => (
                <div
                  key={s.label}
                  className="w-8 h-8 flex items-center justify-center border border-ct-border hover:border-ct-cyan transition-colors font-mono text-[9px] text-ct-gray hover:text-ct-cyan cursor-none"
                >
                  {s.icon}
                </div>
              ))}
            </div>
          </div>

          {/* Right: manifesto */}
          <div className="space-y-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-px bg-ct-cyan" />
              <span className="font-mono text-[10px] text-ct-cyan tracking-[0.4em] uppercase">
                The Vision
              </span>
            </div>

            <blockquote className="relative">
              <div className="absolute -left-4 top-0 bottom-0 w-0.5 bg-gradient-to-b from-ct-cyan to-ct-blue" />
              <p className="font-body text-xl lg:text-2xl text-white leading-relaxed font-light pl-8">
                "AI isn't a product you buy. It's infrastructure you build.
                The teams who own their compute will own their future."
              </p>
            </blockquote>

            <div className="space-y-4 text-ct-gray font-body text-base leading-relaxed">
              <p>
                CodeTetra was founded on a single conviction: the AI revolution
                belongs to builders, not renters. As cloud GPU costs spiral,
                owning your inference and training infrastructure isn't just
                cheaper — it's a strategic moat.
              </p>
              <p>
                We source, configure, and deliver enterprise AI servers tailored
                to your exact workload. From a single H100 node to petaflop clusters,
                we get you from zero to training runs in under 30 days.
              </p>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-ct-border">
              {[
                { val: '50+', label: 'Deployments' },
                { val: '₹15Cr', label: 'Infrastructure Delivered' },
                { val: '23 days', label: 'Avg Delivery' },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="font-display text-2xl font-black text-ct-cyan">{stat.val}</div>
                  <div className="font-mono text-[10px] text-ct-gray tracking-wider mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
