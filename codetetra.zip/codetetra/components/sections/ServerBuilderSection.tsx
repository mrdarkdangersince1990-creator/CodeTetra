'use client';

import { useState } from 'react';

const COMPONENTS = [
  {
    id: 'gpu',
    label: 'GPU',
    icon: '⬡',
    options: [
      { name: 'H100 SXM5', price: 250000, perf: 100, color: '#00D4FF' },
      { name: 'A100 80GB', price: 150000, perf: 70, color: '#0066FF' },
      { name: 'RTX 4090', price: 80000, perf: 45, color: '#7B68EE' },
    ],
  },
  {
    id: 'cpu',
    label: 'CPU',
    icon: '◈',
    options: [
      { name: 'AMD EPYC 9654', price: 45000, perf: 95, color: '#FF6B00' },
      { name: 'Intel Xeon Platinum', price: 40000, perf: 88, color: '#00A8E8' },
      { name: 'AMD EPYC 7763', price: 25000, perf: 75, color: '#FF6B00' },
    ],
  },
  {
    id: 'ram',
    label: 'RAM',
    icon: '▤',
    options: [
      { name: '2TB DDR5 ECC', price: 60000, perf: 100, color: '#00FF88' },
      { name: '1TB DDR5 ECC', price: 35000, perf: 70, color: '#00FF88' },
      { name: '512GB DDR5 ECC', price: 20000, perf: 45, color: '#00FF88' },
    ],
  },
  {
    id: 'storage',
    label: 'Storage',
    icon: '◫',
    options: [
      { name: '100TB NVMe RAID', price: 90000, perf: 100, color: '#FFD700' },
      { name: '50TB NVMe RAID', price: 50000, perf: 70, color: '#FFD700' },
      { name: '20TB SSD Array', price: 25000, perf: 40, color: '#FFD700' },
    ],
  },
  {
    id: 'network',
    label: 'Network',
    icon: '◎',
    options: [
      { name: '400GbE InfiniBand', price: 75000, perf: 100, color: '#FF2D55' },
      { name: '200GbE Ethernet', price: 40000, perf: 70, color: '#FF2D55' },
      { name: '100GbE Ethernet', price: 20000, perf: 45, color: '#FF2D55' },
    ],
  },
  {
    id: 'cooling',
    label: 'Cooling',
    icon: '❄',
    options: [
      { name: 'Liquid Immersion', price: 80000, perf: 100, color: '#00D4FF' },
      { name: 'Direct Liquid', price: 45000, perf: 80, color: '#00D4FF' },
      { name: 'Air + Vapor Chamber', price: 20000, perf: 55, color: '#00D4FF' },
    ],
  },
];

function formatINR(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(1)}Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
  return `₹${n.toLocaleString('en-IN')}`;
}

export default function ServerBuilderSection() {
  const [selected, setSelected] = useState<Record<string, number>>({
    gpu: 0, cpu: 0, ram: 0, storage: 0, network: 0, cooling: 0,
  });

  const totalPrice = COMPONENTS.reduce((acc, comp) => {
    return acc + comp.options[selected[comp.id]].price;
  }, 0);

  const avgPerf = COMPONENTS.reduce((acc, comp) => {
    return acc + comp.options[selected[comp.id]].perf;
  }, 0) / COMPONENTS.length;

  return (
    <section id="builder" className="relative min-h-screen py-32">
      <div className="absolute inset-0 bg-gradient-to-b from-ct-dark/80 to-ct-black/90 pointer-events-none" />

      <div className="max-w-[1400px] mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="mb-16 flex items-start justify-between flex-wrap gap-6">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-px bg-ct-orange" />
              <span className="font-mono text-[10px] text-ct-orange tracking-[0.4em] uppercase">
                Configuration / Server Builder
              </span>
            </div>
            <h2 className="font-display text-4xl lg:text-6xl font-black text-white leading-tight">
              BUILD YOUR
              <br />
              <span className="text-ct-orange">PERFECT SERVER</span>
            </h2>
          </div>

          {/* Live summary */}
          <div className="glass-card p-6 clip-corner-lg min-w-[260px]">
            <div className="font-mono text-[10px] text-ct-gray mb-3 tracking-widest">SYSTEM ESTIMATE</div>
            <div className="font-display text-3xl font-black text-ct-green mb-1">
              {formatINR(totalPrice)}
            </div>
            <div className="font-mono text-[10px] text-ct-gray mb-4">Per server unit</div>

            {/* Performance meter */}
            <div className="space-y-2">
              <div className="flex justify-between font-mono text-[10px] text-ct-gray">
                <span>PERF SCORE</span>
                <span className="text-ct-cyan">{Math.round(avgPerf)}/100</span>
              </div>
              <div className="h-1.5 bg-ct-border rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{
                    width: `${avgPerf}%`,
                    background: avgPerf > 80 ? '#00FF88' : avgPerf > 50 ? '#00D4FF' : '#FF6B00',
                  }}
                />
              </div>
            </div>

            <button className="w-full mt-5 btn-primary text-[10px] py-3 justify-center">
              Request Quote
            </button>
          </div>
        </div>

        {/* Component grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {COMPONENTS.map((comp) => {
            const sel = selected[comp.id];
            const opt = comp.options[sel];
            return (
              <div key={comp.id} className="glass-card p-5 clip-corner">
                {/* Component header */}
                <div className="flex items-center gap-2 mb-4">
                  <span style={{ color: opt.color, fontSize: '18px' }}>{comp.icon}</span>
                  <span className="font-mono text-[11px] text-ct-gray tracking-widest uppercase">{comp.label}</span>
                  <div className="ml-auto font-mono text-[10px]" style={{ color: opt.color }}>
                    {formatINR(opt.price)}
                  </div>
                </div>

                {/* Current selection display */}
                <div
                  className="text-sm font-body font-semibold text-white mb-3 pb-3 border-b border-ct-border"
                >
                  {opt.name}
                </div>

                {/* Options */}
                <div className="space-y-2">
                  {comp.options.map((option, i) => (
                    <button
                      key={i}
                      onClick={() => setSelected(prev => ({ ...prev, [comp.id]: i }))}
                      className="w-full flex items-center justify-between px-3 py-2 text-left transition-all duration-200"
                      style={{
                        background: sel === i ? `${opt.color}12` : 'transparent',
                        border: `1px solid ${sel === i ? opt.color : 'rgba(26,35,50,0.8)'}`,
                      }}
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className="w-1.5 h-1.5 rounded-full"
                          style={{
                            background: sel === i ? opt.color : '#1A2332',
                            boxShadow: sel === i ? `0 0 6px ${opt.color}` : 'none',
                          }}
                        />
                        <span className="font-mono text-[10px] text-ct-light">{option.name}</span>
                      </div>
                      <span className="font-mono text-[10px]" style={{ color: sel === i ? opt.color : '#8892A4' }}>
                        {formatINR(option.price)}
                      </span>
                    </button>
                  ))}
                </div>

                {/* Perf bar */}
                <div className="mt-3 h-px bg-ct-border overflow-hidden">
                  <div
                    className="h-full transition-all duration-500"
                    style={{ width: `${opt.perf}%`, background: opt.color }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
