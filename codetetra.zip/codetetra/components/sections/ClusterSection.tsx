'use client';

import { useState } from 'react';

const CLUSTER_CONFIGS = [
  { label: 'Starter', nodes: 4, gpus: 16, bandwidth: '400Gbps', latency: '< 2μs' },
  { label: 'Growth', nodes: 8, gpus: 32, bandwidth: '800Gbps', latency: '< 2μs' },
  { label: 'AI Lab', nodes: 16, gpus: 64, bandwidth: '1.6Tbps', latency: '< 1μs' },
  { label: 'Enterprise', nodes: 32, gpus: 128, bandwidth: '3.2Tbps', latency: '< 1μs' },
  { label: 'Hyperscale', nodes: 64, gpus: 256, bandwidth: '6.4Tbps', latency: '< 0.5μs' },
];

export default function ClusterSection() {
  const [activeConfig, setActiveConfig] = useState(2);
  const config = CLUSTER_CONFIGS[activeConfig];

  const nodeCount = config.nodes;
  const nodePositions = Array.from({ length: nodeCount }, (_, i) => {
    const angle = (i / nodeCount) * Math.PI * 2;
    const r = 38;
    return {
      x: 50 + r * Math.cos(angle),
      y: 50 + r * Math.sin(angle),
    };
  });

  return (
    <section id="cluster" className="relative min-h-screen py-32">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ct-dark/70 to-ct-black/80 pointer-events-none" />

      <div className="max-w-[1400px] mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-px bg-ct-green" />
            <span className="font-mono text-[10px] text-ct-green tracking-[0.4em] uppercase">
              Architecture / Cluster Topology
            </span>
          </div>
          <h2 className="font-display text-4xl lg:text-6xl font-black text-white leading-tight">
            SCALE WITHOUT
            <br />
            <span className="text-ct-green">LIMITS</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* SVG cluster visualization */}
          <div className="relative aspect-square max-w-md mx-auto lg:mx-0">
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {/* Connection lines */}
              {nodePositions.map((pos, i) =>
                nodePositions.slice(i + 1).map((pos2, j) => {
                  if (j > 2) return null;
                  return (
                    <line
                      key={`${i}-${j}`}
                      x1={pos.x} y1={pos.y}
                      x2={pos2.x} y2={pos2.y}
                      stroke="#00D4FF"
                      strokeWidth="0.2"
                      opacity="0.2"
                    />
                  );
                })
              )}

              {/* Lines to center */}
              {nodePositions.map((pos, i) => (
                <line
                  key={`center-${i}`}
                  x1={50} y1={50}
                  x2={pos.x} y2={pos.y}
                  stroke="#0066FF"
                  strokeWidth="0.15"
                  opacity="0.3"
                  strokeDasharray="1 2"
                >
                  <animate
                    attributeName="strokeDashoffset"
                    values="3;0"
                    dur={`${1 + (i * 0.1)}s`}
                    repeatCount="indefinite"
                  />
                </line>
              ))}

              {/* Node circles */}
              {nodePositions.map((pos, i) => (
                <g key={i}>
                  <circle cx={pos.x} cy={pos.y} r="2.5" fill="#070B10" stroke="#00D4FF" strokeWidth="0.4" />
                  <circle cx={pos.x} cy={pos.y} r="1" fill="#00D4FF">
                    <animate
                      attributeName="opacity"
                      values="1;0.3;1"
                      dur={`${1.5 + (i * 0.12)}s`}
                      repeatCount="indefinite"
                    />
                  </circle>
                  {/* Data packets */}
                  <circle r="0.5" fill="#00FF88">
                    <animateMotion
                      dur={`${2 + (i * 0.2)}s`}
                      repeatCount="indefinite"
                      path={`M${pos.x},${pos.y} L50,50`}
                    />
                  </circle>
                </g>
              ))}

              {/* Central hub */}
              <circle cx="50" cy="50" r="5" fill="#070B10" stroke="#00FF88" strokeWidth="0.6">
                <animate attributeName="r" values="5;5.5;5" dur="2s" repeatCount="indefinite" />
              </circle>
              <circle cx="50" cy="50" r="2" fill="#00FF88">
                <animate attributeName="opacity" values="1;0.5;1" dur="1.5s" repeatCount="indefinite" />
              </circle>

              {/* Orbit ring */}
              <circle cx="50" cy="50" r="38" fill="none" stroke="#00D4FF" strokeWidth="0.2" strokeDasharray="1 3" opacity="0.4">
                <animateTransform
                  attributeName="transform"
                  type="rotate"
                  values="0 50 50;360 50 50"
                  dur="30s"
                  repeatCount="indefinite"
                />
              </circle>
            </svg>

            {/* Center label */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="font-display text-2xl font-black text-ct-green">{config.nodes}</div>
                <div className="font-mono text-[9px] text-ct-gray tracking-widest">NODES</div>
              </div>
            </div>
          </div>

          {/* Right: config selector + stats */}
          <div className="space-y-6">
            {/* Tier buttons */}
            <div className="space-y-2">
              <div className="font-mono text-[10px] text-ct-gray tracking-widest mb-4">SELECT SCALE</div>
              {CLUSTER_CONFIGS.map((c, i) => (
                <button
                  key={i}
                  onClick={() => setActiveConfig(i)}
                  className="w-full flex items-center justify-between px-5 py-3 text-left transition-all duration-300"
                  style={{
                    background: activeConfig === i ? 'rgba(0,255,136,0.08)' : 'rgba(13,17,23,0.6)',
                    border: `1px solid ${activeConfig === i ? '#00FF88' : 'rgba(26,35,50,0.8)'}`,
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-1.5 h-1.5 rounded-full"
                      style={{
                        background: activeConfig === i ? '#00FF88' : '#1A2332',
                        boxShadow: activeConfig === i ? '0 0 8px #00FF88' : 'none',
                      }}
                    />
                    <span className="font-body font-semibold text-white text-sm">{c.label}</span>
                    <span className="font-mono text-[9px] text-ct-gray">{c.gpus} GPUs</span>
                  </div>
                  <span className="font-mono text-[10px]" style={{ color: activeConfig === i ? '#00FF88' : '#8892A4' }}>
                    {c.nodes} nodes
                  </span>
                </button>
              ))}
            </div>

            {/* Live stats */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'GPU COUNT', val: `${config.gpus}x H100` },
                { label: 'BANDWIDTH', val: config.bandwidth },
                { label: 'LATENCY', val: config.latency },
                { label: 'UPTIME SLA', val: '99.99%' },
              ].map((stat) => (
                <div key={stat.label} className="glass-card p-4 clip-corner">
                  <div className="font-mono text-[9px] text-ct-gray mb-1 tracking-widest">{stat.label}</div>
                  <div className="font-display text-base font-bold text-ct-green">{stat.val}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
