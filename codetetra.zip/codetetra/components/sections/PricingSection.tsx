'use client';

import { useState } from 'react';

const TIERS = [
  {
    id: 'starter',
    label: 'Starter',
    price: '10L',
    priceINR: '₹10,00,000',
    tagline: 'First steps into AI compute',
    color: '#00D4FF',
    gpus: 2,
    nodes: 1,
    features: [
      '2× NVIDIA H100 SXM5',
      '160GB GPU VRAM',
      '512GB System RAM',
      '20TB NVMe Storage',
      '100Gbps Network',
      '24/7 Remote Support',
    ],
    highlight: false,
  },
  {
    id: 'growth',
    label: 'Growth',
    price: '20L',
    priceINR: '₹20,00,000',
    tagline: 'Production-grade AI workloads',
    color: '#0066FF',
    gpus: 4,
    nodes: 2,
    features: [
      '4× NVIDIA H100 SXM5',
      '320GB GPU VRAM',
      '1TB System RAM',
      '50TB NVMe RAID',
      '200Gbps Network',
      'NVLink 4.0 Bridge',
      'Priority Support',
    ],
    highlight: false,
  },
  {
    id: 'ailab',
    label: 'AI Lab',
    price: '40L',
    priceINR: '₹40,00,000',
    tagline: 'Research-grade infrastructure',
    color: '#00FF88',
    gpus: 8,
    nodes: 4,
    features: [
      '8× NVIDIA H100 SXM5',
      '640GB GPU VRAM',
      '2TB DDR5 ECC RAM',
      '100TB NVMe RAID',
      '400Gbps InfiniBand',
      'Full NVLink Mesh',
      'Liquid Cooling',
      'Dedicated Engineer',
    ],
    highlight: true,
  },
  {
    id: 'enterprise',
    label: 'Enterprise',
    price: '70L',
    priceINR: '₹70,00,000',
    tagline: 'Multi-tenant AI fabric',
    color: '#FF6B00',
    gpus: 16,
    nodes: 8,
    features: [
      '16× NVIDIA H100 SXM5',
      '1.28TB GPU VRAM',
      '4TB DDR5 ECC RAM',
      '200TB Storage Array',
      '800Gbps InfiniBand',
      'Immersion Cooling',
      'Custom BIOS Tuning',
      'On-site Engineer',
      'SLA 99.99%',
    ],
    highlight: false,
  },
  {
    id: 'hyperscale',
    label: 'Hyperscale',
    price: '1Cr+',
    priceINR: '₹1,00,00,000+',
    tagline: 'Datacenter-grade AI clusters',
    color: '#FF2D55',
    gpus: 64,
    nodes: 32,
    features: [
      '64+ NVIDIA H100 SXM5',
      '5TB+ GPU VRAM',
      '16TB+ System RAM',
      'Petabyte Storage',
      '6.4Tbps Network Fabric',
      'Custom Rack Design',
      'Full DC Integration',
      'Dedicated Team',
      'White-glove SLA',
    ],
    highlight: false,
  },
];

export default function PricingSection() {
  const [active, setActive] = useState(2);

  return (
    <section id="pricing" className="relative min-h-screen py-32">
      <div className="absolute inset-0 bg-gradient-to-b from-ct-black/80 to-ct-dark/90 pointer-events-none" />

      <div className="max-w-[1400px] mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="mb-16 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-px bg-ct-red" />
            <span className="font-mono text-[10px] text-ct-red tracking-[0.4em] uppercase">
              Pricing / Infrastructure Tiers
            </span>
            <div className="w-8 h-px bg-ct-red" />
          </div>
          <h2 className="font-display text-4xl lg:text-6xl font-black text-white leading-tight">
            SCALE OF
            <br />
            <span className="text-ct-red">INTELLIGENCE</span>
          </h2>
          <p className="mt-6 text-ct-gray font-body text-lg max-w-2xl mx-auto">
            From first experiments to petaflop clusters. All pricing is for complete
            system delivery, installation, and first-year support.
          </p>
        </div>

        {/* Tier selector tabs */}
        <div className="flex overflow-x-auto gap-1 mb-8 pb-2">
          {TIERS.map((tier, i) => (
            <button
              key={tier.id}
              onClick={() => setActive(i)}
              className="shrink-0 px-5 py-2.5 font-mono text-[10px] tracking-widest uppercase transition-all duration-300"
              style={{
                background: active === i ? tier.color + '20' : 'transparent',
                border: `1px solid ${active === i ? tier.color : 'rgba(26,35,50,0.8)'}`,
                color: active === i ? tier.color : '#8892A4',
              }}
            >
              {tier.label}
            </button>
          ))}
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {TIERS.map((tier, i) => {
            const isActive = active === i;
            return (
              <div
                key={tier.id}
                onClick={() => setActive(i)}
                className="glass-card p-5 clip-corner cursor-none relative transition-all duration-500 group"
                style={{
                  borderColor: isActive ? tier.color : 'rgba(0,212,255,0.08)',
                  transform: isActive ? 'translateY(-8px)' : 'translateY(0)',
                  boxShadow: isActive ? `0 20px 60px ${tier.color}25` : 'none',
                }}
              >
                {tier.highlight && (
                  <div
                    className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 font-mono text-[9px] tracking-widest"
                    style={{ background: tier.color, color: '#000' }}
                  >
                    MOST POPULAR
                  </div>
                )}

                <div className="mb-4">
                  <div
                    className="font-mono text-[9px] tracking-widest mb-2"
                    style={{ color: tier.color }}
                  >
                    {tier.label.toUpperCase()}
                  </div>
                  <div className="font-display text-3xl font-black text-white">
                    {tier.price}
                  </div>
                  <div className="font-mono text-[9px] text-ct-gray mt-1">
                    {tier.priceINR}
                  </div>
                </div>

                <div
                  className="text-[12px] font-body text-ct-gray mb-5 pb-4 border-b"
                  style={{ borderColor: `${tier.color}30` }}
                >
                  {tier.tagline}
                </div>

                <div className="space-y-2 mb-6">
                  {tier.features.map((f, fi) => (
                    <div key={fi} className="flex items-start gap-2">
                      <div
                        className="w-1 h-1 rounded-full mt-1.5 shrink-0"
                        style={{ background: tier.color }}
                      />
                      <span className="font-mono text-[10px] text-ct-gray leading-relaxed">{f}</span>
                    </div>
                  ))}
                </div>

                {/* GPU count indicator */}
                <div className="flex gap-1 mb-5 flex-wrap">
                  {Array.from({ length: Math.min(tier.gpus, 8) }, (_, j) => (
                    <div
                      key={j}
                      className="w-4 h-2 rounded-sm"
                      style={{
                        background: tier.color,
                        opacity: 0.6 + (j / 8) * 0.4,
                      }}
                    />
                  ))}
                  {tier.gpus > 8 && (
                    <div className="font-mono text-[9px]" style={{ color: tier.color }}>
                      +{tier.gpus - 8}
                    </div>
                  )}
                </div>

                <button
                  className="w-full py-3 font-mono text-[10px] tracking-widest uppercase transition-all duration-300"
                  style={{
                    border: `1px solid ${tier.color}`,
                    color: isActive ? '#000' : tier.color,
                    background: isActive ? tier.color : 'transparent',
                  }}
                >
                  Get Started
                </button>
              </div>
            );
          })}
        </div>

        <p className="mt-8 text-center font-mono text-[10px] text-ct-gray">
          All prices are one-time capex. Financing options available. EMI from ₹1.2L/month.
        </p>
      </div>
    </section>
  );
}
