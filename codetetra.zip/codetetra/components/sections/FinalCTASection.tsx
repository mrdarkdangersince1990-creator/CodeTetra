'use client';

import { useState, useEffect, useRef } from 'react';

const BOOT_SEQUENCE = [
  '> CODETETRA INTELLIGENCE OS v2.4.1',
  '> Initializing GPU fabric...',
  '> [OK] 64× H100 SXM5 detected',
  '> [OK] NVLink mesh: ACTIVE',
  '> [OK] InfiniBand 400G: ONLINE',
  '> [OK] Thermal management: NOMINAL',
  '> Loading inference kernel...',
  '> [OK] CUDA 12.4 runtime loaded',
  '> [OK] cuDNN 9.0 accelerated',
  '> All systems NOMINAL.',
  '> READY FOR INTELLIGENCE.',
];

export default function FinalCTASection() {
  const [booted, setBooted] = useState(false);
  const [lines, setLines] = useState<string[]>([]);
  const [booting, setBooting] = useState(false);
  const termRef = useRef<HTMLDivElement>(null);

  const boot = () => {
    if (booting || booted) return;
    setBooting(true);
    setLines([]);

    BOOT_SEQUENCE.forEach((line, i) => {
      setTimeout(() => {
        setLines(prev => [...prev, line]);
        if (termRef.current) {
          termRef.current.scrollTop = termRef.current.scrollHeight;
        }
        if (i === BOOT_SEQUENCE.length - 1) {
          setTimeout(() => setBooted(true), 500);
          setBooting(false);
        }
      }, i * 280);
    });
  };

  return (
    <section id="contact" className="relative min-h-screen flex items-center py-32">
      <div className="absolute inset-0 bg-gradient-to-b from-ct-dark/80 to-ct-black pointer-events-none" />

      {/* Scanline overlay */}
      <div className="absolute inset-0 scanlines pointer-events-none opacity-30" />

      <div className="max-w-[1400px] mx-auto px-6 relative z-10 w-full">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="mb-12 text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-8 h-px bg-ct-green" />
              <span className="font-mono text-[10px] text-ct-green tracking-[0.4em] uppercase">
                Initiate / System Boot
              </span>
              <div className="w-8 h-px bg-ct-green" />
            </div>
            <h2 className="font-display text-4xl lg:text-6xl font-black text-white leading-tight">
              ACTIVATE YOUR
              <br />
              <span
                style={{
                  background: 'linear-gradient(135deg, #00D4FF 0%, #00FF88 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                INTELLIGENCE
              </span>
            </h2>
          </div>

          {/* Terminal */}
          <div
            className="glass-card clip-corner-lg overflow-hidden"
            style={{ border: `1px solid ${booted ? '#00FF88' : 'rgba(0,212,255,0.2)'}` }}
          >
            {/* Terminal header */}
            <div className="flex items-center gap-2 px-5 py-3 border-b border-ct-border bg-ct-dark/50">
              <div className="w-2.5 h-2.5 rounded-full bg-ct-red" />
              <div className="w-2.5 h-2.5 rounded-full bg-ct-orange" />
              <div className="w-2.5 h-2.5 rounded-full bg-ct-green" />
              <span className="ml-3 font-mono text-[10px] text-ct-gray tracking-widest">
                codetetra@intelligence:~$
              </span>
              {booted && (
                <div className="ml-auto flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-ct-green animate-pulse" />
                  <span className="font-mono text-[9px] text-ct-green">SYSTEM READY</span>
                </div>
              )}
            </div>

            {/* Terminal body */}
            <div
              ref={termRef}
              className="p-6 min-h-[280px] max-h-[280px] overflow-y-auto font-mono text-[12px] leading-7 space-y-0.5"
            >
              {lines.length === 0 && !booting && (
                <div className="text-ct-gray opacity-50">
                  {'>'} Click the button below to activate system...
                </div>
              )}
              {lines.map((line, i) => (
                <div
                  key={i}
                  className={
                    line.includes('[OK]')
                      ? 'text-ct-green'
                      : line.includes('READY')
                      ? 'text-ct-cyan text-glow-cyan'
                      : line.startsWith('> CODETETRA')
                      ? 'text-ct-cyan font-bold'
                      : 'text-ct-light'
                  }
                >
                  {line}
                </div>
              ))}
              {booting && (
                <span className="inline-block w-2 h-4 bg-ct-cyan animate-pulse" />
              )}
            </div>
          </div>

          {/* Boot button */}
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={boot}
              disabled={booted || booting}
              className="btn-primary text-sm py-5 px-12 justify-center clip-corner-lg relative overflow-hidden"
              style={{
                borderColor: booted ? '#00FF88' : '#00D4FF',
                color: booted ? '#00FF88' : '#00D4FF',
              }}
            >
              {booting ? (
                <>
                  <div className="w-3 h-3 border border-ct-cyan border-t-transparent rounded-full animate-spin" />
                  BOOTING...
                </>
              ) : booted ? (
                <>
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M2 7L5.5 10.5L12 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" />
                  </svg>
                  SYSTEM ACTIVE
                </>
              ) : (
                <>
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M7 1V7M4 3.5C2.4 4.5 1.5 6.1 1.5 7.8C1.5 10.7 4 13 7 13C10 13 12.5 10.7 12.5 7.8C12.5 6.1 11.6 4.5 10 3.5" stroke="currentColor" strokeWidth="1.5" />
                  </svg>
                  ACTIVATE SYSTEM
                </>
              )}
            </button>

            <a
              href="mailto:as977100@gmail.com"
              className="btn-primary text-sm py-5 px-8 justify-center"
              style={{ borderColor: '#FF6B00', color: '#FF6B00' }}
            >
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <rect x="1" y="3" width="12" height="8" rx="1" stroke="currentColor" strokeWidth="1" />
                <path d="M1 4L7 8L13 4" stroke="currentColor" strokeWidth="1" />
              </svg>
              Schedule Consultation
            </a>
          </div>

          {/* Bottom tagline */}
          <div className="mt-16 text-center space-y-3">
            <div className="font-display text-sm text-ct-gray tracking-[0.4em] uppercase">
              Build Intelligence. Not Debt.
            </div>
            <div className="font-mono text-[10px] text-ct-border tracking-widest">
              © 2024 CodeTetra. All rights reserved. Made with 16,384 CUDA cores.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
