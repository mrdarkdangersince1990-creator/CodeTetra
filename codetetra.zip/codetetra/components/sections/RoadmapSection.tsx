'use client';

import { useEffect, useRef, useState } from 'react';

const STEPS = [
  {
    id: '01',
    title: 'Consultation',
    sub: 'Day 1–3',
    desc: 'We audit your AI workloads, model sizes, batch requirements, and team scale to architect the right system.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5" />
      </svg>
    ),
    color: '#00D4FF',
  },
  {
    id: '02',
    title: 'Architecture Design',
    sub: 'Day 4–10',
    desc: 'Custom system topology, rack layout, network fabric design, and cooling solution optimized for your use case.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="3" width="18" height="18" rx="1" stroke="currentColor" strokeWidth="1.5" />
        <path d="M3 9H21M9 21V9" stroke="currentColor" strokeWidth="1.5" />
      </svg>
    ),
    color: '#0066FF',
  },
  {
    id: '03',
    title: 'Deployment',
    sub: 'Day 11–21',
    desc: 'Hardware procurement, assembly, burn-in testing, OS imaging, driver installation, and on-site delivery.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M12 2L15.5 8.5L22 9.3L17 14.1L18.2 21L12 17.8L5.8 21L7 14.1L2 9.3L8.5 8.5L12 2Z" stroke="currentColor" strokeWidth="1.5" />
      </svg>
    ),
    color: '#00FF88',
  },
  {
    id: '04',
    title: 'Optimization',
    sub: 'Day 22–30',
    desc: 'Model benchmark runs, CUDA tuning, memory optimization, and performance validation against SLA targets.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M13 2L3 14H12L11 22L21 10H12L13 2Z" stroke="currentColor" strokeWidth="1.5" />
      </svg>
    ),
    color: '#FF6B00',
  },
];

export default function RoadmapSection() {
  const [active, setActive] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setActive(prev => (prev + 1) % STEPS.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section ref={sectionRef} id="roadmap" className="relative min-h-screen py-32">
      <div className="absolute inset-0 bg-gradient-to-b from-ct-dark/90 to-ct-black/95 pointer-events-none" />

      <div className="max-w-[1400px] mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="mb-20 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-px bg-ct-blue" />
            <span className="font-mono text-[10px] text-ct-blue tracking-[0.4em] uppercase">
              Process / Deployment Timeline
            </span>
            <div className="w-8 h-px bg-ct-blue" />
          </div>
          <h2 className="font-display text-4xl lg:text-6xl font-black text-white leading-tight">
            ZERO TO
            <br />
            <span className="text-ct-blue">PRODUCTION</span>
            <br />
            IN 30 DAYS
          </h2>
        </div>

        {/* Horizontal timeline */}
        <div className="relative">
          {/* Connecting line */}
          <div className="absolute top-16 left-0 right-0 h-px bg-ct-border hidden lg:block" />

          {/* Animated progress */}
          <div
            className="absolute top-16 left-0 h-px hidden lg:block transition-all duration-700"
            style={{
              width: `${((active + 1) / STEPS.length) * 100}%`,
              background: STEPS[active].color,
              boxShadow: `0 0 12px ${STEPS[active].color}`,
            }}
          />

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {STEPS.map((step, i) => {
              const isActive = active === i;
              const isPast = i < active;
              return (
                <div
                  key={step.id}
                  onClick={() => setActive(i)}
                  className="cursor-none flex flex-col gap-6"
                >
                  {/* Step indicator */}
                  <div className="flex items-center gap-4 lg:flex-col lg:items-start">
                    <div
                      className="relative w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all duration-500"
                      style={{
                        background: isActive || isPast ? step.color : '#0D1117',
                        border: `2px solid ${isActive ? step.color : isPast ? step.color : '#1A2332'}`,
                        boxShadow: isActive ? `0 0 20px ${step.color}` : 'none',
                      }}
                    >
                      {isPast ? (
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                          <path d="M2 6L5 9L10 3" stroke="#000" strokeWidth="1.5" strokeLinecap="square" />
                        </svg>
                      ) : (
                        <span className="font-mono text-[9px] text-white">{step.id}</span>
                      )}

                      {isActive && (
                        <div
                          className="absolute inset-0 rounded-full animate-ping"
                          style={{ background: step.color, opacity: 0.3 }}
                        />
                      )}
                    </div>

                    <div>
                      <div className="font-mono text-[9px] text-ct-gray tracking-widest">{step.sub}</div>
                    </div>
                  </div>

                  {/* Content */}
                  <div
                    className="glass-card p-6 clip-corner transition-all duration-500"
                    style={{
                      borderColor: isActive ? step.color : 'rgba(0,212,255,0.06)',
                      background: isActive ? `${step.color}08` : 'rgba(13,17,23,0.8)',
                    }}
                  >
                    <div className="mb-3" style={{ color: step.color }}>
                      {step.icon}
                    </div>
                    <h3
                      className="font-display text-lg font-bold mb-3 transition-colors duration-300"
                      style={{ color: isActive ? step.color : 'white' }}
                    >
                      {step.title}
                    </h3>
                    <p className="font-body text-sm text-ct-gray leading-relaxed">
                      {step.desc}
                    </p>

                    <div
                      className="mt-4 h-px transition-all duration-700"
                      style={{
                        background: step.color,
                        width: isActive ? '100%' : isPast ? '100%' : '0%',
                        opacity: isActive ? 1 : isPast ? 0.4 : 0,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom note */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-4 glass-card px-8 py-4">
            <div className="w-2 h-2 rounded-full bg-ct-green animate-pulse" />
            <span className="font-mono text-[11px] text-ct-gray tracking-widest">
              Average delivery: 23 days. Rush deployment available in 10 days.
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
