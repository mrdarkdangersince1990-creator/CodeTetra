'use client';

import { useEffect, useRef } from 'react';

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    // Stagger reveal animation
    const els = sectionRef.current?.querySelectorAll('[data-reveal]');
    els?.forEach((el, i) => {
      (el as HTMLElement).style.animationDelay = `${2.8 + i * 0.15}s`;
      (el as HTMLElement).style.animationFillMode = 'forwards';
    });
  }, []);

  return (
    <section
      ref={sectionRef}
      id="home"
      className="relative min-h-screen flex flex-col justify-center overflow-hidden"
    >
      {/* Horizontal rule decorators */}
      <div className="absolute top-16 left-0 right-0 h-px bg-gradient-to-r from-transparent via-ct-cyan/20 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-ct-cyan/20 to-transparent" />

      {/* Radial glow */}
      <div className="absolute inset-0 bg-radial-glow pointer-events-none" />

      <div className="max-w-[1400px] mx-auto px-6 py-32 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="space-y-8">
            {/* System tag */}
            <div
              data-reveal
              className="opacity-0 animate-[fadeInUp_0.8s_ease_forwards] inline-flex items-center gap-3"
            >
              <div className="flex items-center gap-2 px-3 py-1.5 border border-ct-cyan/30 bg-ct-cyan/5">
                <div className="w-1.5 h-1.5 rounded-full bg-ct-green animate-pulse" />
                <span className="font-mono text-[10px] text-ct-cyan tracking-[0.3em] uppercase">
                  System Online — v2.4.1
                </span>
              </div>
            </div>

            {/* Main headline */}
            <div className="space-y-2">
              <h1
                data-reveal
                className="opacity-0 animate-[fadeInUp_0.9s_ease_forwards] font-display text-5xl lg:text-7xl font-black text-white leading-[0.9] tracking-tight"
              >
                YOU DON'T
                <br />
                <span className="text-glow-cyan text-ct-cyan">BUY</span>
                <br />
                SERVERS.
              </h1>
              <h1
                data-reveal
                className="opacity-0 animate-[fadeInUp_0.9s_ease_forwards] font-display text-5xl lg:text-7xl font-black leading-[0.9] tracking-tight"
                style={{
                  background: 'linear-gradient(135deg, #00D4FF 0%, #0066FF 50%, #00FF88 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                YOU BUILD
                <br />
                INTELLIGENCE.
              </h1>
            </div>

            {/* Subheadline */}
            <p
              data-reveal
              className="opacity-0 animate-[fadeInUp_0.8s_ease_forwards] font-body text-ct-gray text-lg leading-relaxed max-w-lg"
            >
              Enterprise-grade AI infrastructure. GPU clusters, custom server builds,
              and hyperscale deployments — engineered for teams who think in teraflops.
            </p>

            {/* CTA group */}
            <div
              data-reveal
              className="opacity-0 animate-[fadeInUp_0.8s_ease_forwards] flex flex-col sm:flex-row gap-4"
            >
              <button
                onClick={() => document.querySelector('#pricing')?.scrollIntoView({ behavior: 'smooth' })}
                className="btn-primary text-sm py-4 px-8 clip-corner"
              >
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                  <path d="M7 1L13 7M13 7L7 13M13 7H1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" />
                </svg>
                Configure Your Cluster
              </button>
              <button
                onClick={() => document.querySelector('#gpu')?.scrollIntoView({ behavior: 'smooth' })}
                className="flex items-center gap-2 px-8 py-4 text-ct-gray hover:text-white font-mono text-[11px] tracking-widest transition-colors uppercase"
              >
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                  <circle cx="7" cy="7" r="6" stroke="currentColor" strokeWidth="1" />
                  <path d="M7 4V7L9 9" stroke="currentColor" strokeWidth="1" strokeLinecap="square" />
                </svg>
                Watch Demo
              </button>
            </div>

            {/* Stats */}
            <div
              data-reveal
              className="opacity-0 animate-[fadeInUp_0.8s_ease_forwards] grid grid-cols-3 gap-6 pt-4 border-t border-ct-border"
            >
              {[
                { val: '16,384', label: 'CUDA Cores' },
                { val: '80GB', label: 'HBM3 VRAM' },
                { val: '3.35', label: 'TB/s Memory BW' },
              ].map((stat) => (
                <div key={stat.label} className="space-y-1">
                  <div className="font-display text-xl font-bold text-ct-cyan">{stat.val}</div>
                  <div className="font-mono text-[10px] text-ct-gray tracking-wider">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: spacer for 3D content */}
          <div className="hidden lg:block relative h-[600px]">
            {/* Floating spec cards */}
            <div className="absolute top-8 right-0 glass-card p-4 clip-corner animate-float">
              <div className="font-mono text-[9px] text-ct-gray mb-2 tracking-widest">ACTIVE NODE</div>
              <div className="font-display text-sm font-bold text-ct-cyan">H100 SXM5</div>
              <div className="mt-2 flex gap-1.5">
                {[85, 92, 78, 96, 88].map((v, i) => (
                  <div key={i} className="w-1.5 bg-ct-border rounded-sm overflow-hidden" style={{ height: '32px' }}>
                    <div
                      className="w-full bg-ct-cyan"
                      style={{ height: `${v}%`, marginTop: `${100 - v}%` }}
                    />
                  </div>
                ))}
              </div>
            </div>

            <div
              className="absolute bottom-16 left-0 glass-card p-4 clip-corner animate-float"
              style={{ animationDelay: '2s' }}
            >
              <div className="font-mono text-[9px] text-ct-gray mb-1 tracking-widest">THROUGHPUT</div>
              <div className="font-display text-2xl font-bold text-ct-green">1.97 PF/s</div>
              <div className="font-mono text-[9px] text-ct-gray">FP8 PERFORMANCE</div>
            </div>

            <div
              className="absolute top-1/2 right-4 glass-card p-4 clip-corner animate-float"
              style={{ animationDelay: '1s' }}
            >
              <div className="font-mono text-[9px] text-ct-orange mb-1 tracking-widest">TEMP</div>
              <div className="font-display text-lg font-bold text-white">38.4°C</div>
              <div className="h-1 w-full bg-ct-border mt-2 rounded-full overflow-hidden">
                <div className="h-full bg-ct-orange w-2/5 rounded-full" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <span className="font-mono text-[9px] text-ct-gray tracking-[0.3em]">SCROLL TO EXPLORE</span>
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M10 4V16M10 16L4 10M10 16L16 10" stroke="#00D4FF" strokeWidth="1" strokeLinecap="square" />
        </svg>
      </div>

      <style jsx>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </section>
  );
}
