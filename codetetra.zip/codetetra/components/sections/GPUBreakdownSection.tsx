'use client';

import { useRef, useEffect } from 'react';

const GPU_SPECS = [
  {
    id: '01',
    name: 'CUDA Die',
    spec: '16,384 CUDA Cores',
    detail: 'Massively parallel GPU compute architecture with 4th-gen Tensor Cores for peak AI throughput.',
    color: '#00D4FF',
    stat: '1,979 TF/s',
  },
  {
    id: '02',
    name: 'HBM3 VRAM',
    spec: '80GB / 3.35 TB/s',
    detail: 'High-bandwidth memory stacked directly on the package, enabling in-GPU model loading at scale.',
    color: '#FF6B00',
    stat: '80GB Stack',
  },
  {
    id: '03',
    name: 'NVLink 4.0',
    spec: '900 GB/s Bidirectional',
    detail: 'GPU-to-GPU interconnect enabling transparent shared memory pools across 8 or 16 GPUs.',
    color: '#00FF88',
    stat: '900 GB/s',
  },
  {
    id: '04',
    name: 'PCIe 5.0',
    spec: 'x16 Gen 5 Lane',
    detail: 'Host interconnect delivering 128 GB/s, enabling high-throughput CPU-GPU data exchange.',
    color: '#FFD700',
    stat: '128 GB/s',
  },
  {
    id: '05',
    name: 'Vapor Chamber',
    spec: 'Triple Slot Cooling',
    detail: 'Advanced thermal solution sustaining 700W TDP under extended AI training workloads.',
    color: '#8892A4',
    stat: '700W TDP',
  },
];

export default function GPUBreakdownSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const cards = entry.target.querySelectorAll('[data-card]');
            cards.forEach((card, i) => {
              setTimeout(() => {
                (card as HTMLElement).style.opacity = '1';
                (card as HTMLElement).style.transform = 'translateY(0)';
              }, i * 100);
            });
          }
        });
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} id="gpu" className="relative min-h-screen py-32">
      {/* Background: dark gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ct-black/60 to-ct-dark/80 pointer-events-none" />

      <div className="max-w-[1400px] mx-auto px-6 relative z-10">
        {/* Section header */}
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-px bg-ct-cyan" />
            <span className="font-mono text-[10px] text-ct-cyan tracking-[0.4em] uppercase">
              Anatomy / H100 SXM5
            </span>
          </div>
          <h2 className="font-display text-4xl lg:text-6xl font-black text-white leading-tight">
            INSIDE THE
            <br />
            <span className="text-ct-cyan">INTELLIGENCE ENGINE</span>
          </h2>
          <p className="mt-6 text-ct-gray font-body text-lg max-w-xl leading-relaxed">
            Every component tuned for AI. Hover the 3D model to explore
            individual parts — or dive into the specs below.
          </p>
        </div>

        {/* Right-aligned spec list */}
        <div className="lg:ml-auto lg:max-w-2xl space-y-3">
          {GPU_SPECS.map((spec) => (
            <div
              key={spec.id}
              data-card
              className="group glass-card p-5 clip-corner cursor-none transition-all duration-300 hover:border-opacity-100"
              style={{
                opacity: 0,
                transform: 'translateY(20px)',
                transition: 'opacity 0.5s ease, transform 0.5s ease, border-color 0.3s ease',
                borderColor: 'rgba(0,212,255,0.1)',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = spec.color;
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = 'rgba(0,212,255,0.1)';
              }}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-4">
                  <span className="font-mono text-[10px] text-ct-gray pt-1">{spec.id}</span>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <div
                        className="w-2 h-2 rounded-full"
                        style={{ background: spec.color, boxShadow: `0 0 8px ${spec.color}` }}
                      />
                      <span className="font-display text-sm font-bold text-white">{spec.name}</span>
                    </div>
                    <div className="font-mono text-[10px] mb-2" style={{ color: spec.color }}>
                      {spec.spec}
                    </div>
                    <p className="font-body text-[13px] text-ct-gray leading-relaxed">
                      {spec.detail}
                    </p>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div
                    className="font-display text-lg font-bold"
                    style={{ color: spec.color }}
                  >
                    {spec.stat}
                  </div>
                </div>
              </div>

              {/* Bottom progress bar on hover */}
              <div className="mt-3 h-px bg-ct-border overflow-hidden">
                <div
                  className="h-full w-0 group-hover:w-full transition-all duration-700"
                  style={{ background: spec.color }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Bottom note */}
        <div className="mt-12 flex items-center gap-3 text-ct-gray">
          <div className="w-4 h-px bg-ct-border" />
          <span className="font-mono text-[10px] tracking-widest">
            All specs for NVIDIA H100 SXM5. CodeTetra also supports A100, RTX 4090, and L40S deployments.
          </span>
        </div>
      </div>
    </section>
  );
}
