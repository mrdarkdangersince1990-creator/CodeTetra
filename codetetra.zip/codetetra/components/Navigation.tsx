'use client';

import { useEffect, useState } from 'react';

const navLinks = [
  { label: 'Infrastructure', href: '#gpu' },
  { label: 'Builder', href: '#builder' },
  { label: 'Cluster', href: '#cluster' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'About', href: '#founder' },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [time, setTime] = useState('');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('en-IN', { hour12: false }));
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-ct-black/80 backdrop-blur-xl border-b border-ct-border'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-[1400px] mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="flex items-center gap-3 group"
        >
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
            <polygon
              points="16,2 30,26 2,26"
              fill="none"
              stroke="#00D4FF"
              strokeWidth="1.5"
            />
            <polygon
              points="16,9 24,23 8,23"
              fill="none"
              stroke="#0066FF"
              strokeWidth="1"
              opacity="0.7"
            />
            <circle cx="16" cy="16" r="2" fill="#00D4FF" />
          </svg>
          <div>
            <div className="font-display text-sm font-bold text-white tracking-[0.25em] group-hover:text-ct-cyan transition-colors">
              CODETETRA
            </div>
            <div className="font-mono text-[8px] text-ct-gray tracking-[0.3em] -mt-0.5">
              AI INFRASTRUCTURE
            </div>
          </div>
        </button>

        {/* Center links */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => scrollTo(link.href)}
              className="font-mono text-[11px] text-ct-gray hover:text-ct-cyan transition-colors tracking-widest uppercase relative group"
            >
              {link.label}
              <span className="absolute -bottom-1 left-0 w-0 h-px bg-ct-cyan group-hover:w-full transition-all duration-300" />
            </button>
          ))}
        </div>

        {/* Right: time + CTA */}
        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-ct-green animate-pulse" />
            <span className="font-mono text-[10px] text-ct-gray tracking-widest">
              IST {time}
            </span>
          </div>
          <button
            onClick={() => scrollTo('#pricing')}
            className="btn-primary text-[10px] py-2.5 px-5"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-ct-cyan animate-pulse" />
            Deploy Now
          </button>
        </div>
      </div>
    </nav>
  );
}
