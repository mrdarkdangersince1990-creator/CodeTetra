'use client';

import { useFrame, useThree } from '@react-three/fiber';
import { useRef } from 'react';
import * as THREE from 'three';

interface CameraRigProps {
  scrollProgress: number;
}

// Camera waypoints along the scroll journey
const cameraPath = [
  { pos: new THREE.Vector3(0, 2, 12), target: new THREE.Vector3(0, 0, 0) },       // Hero: overview
  { pos: new THREE.Vector3(3, 1, 7), target: new THREE.Vector3(0, 0, 0) },        // GPU breakdown
  { pos: new THREE.Vector3(-4, 3, 8), target: new THREE.Vector3(0, 0, 0) },       // Server builder
  { pos: new THREE.Vector3(0, 8, 14), target: new THREE.Vector3(0, 0, 0) },       // Cluster top view
  { pos: new THREE.Vector3(6, 2, 10), target: new THREE.Vector3(0, 0, 0) },       // Pricing
  { pos: new THREE.Vector3(-2, 1, 9), target: new THREE.Vector3(0, 0, 0) },       // Roadmap
  { pos: new THREE.Vector3(0, 0, 8), target: new THREE.Vector3(0, 0, 0) },        // Founder
  { pos: new THREE.Vector3(0, -1, 6), target: new THREE.Vector3(0, 0, 0) },       // Final CTA
];

export default function CameraRig({ scrollProgress }: CameraRigProps) {
  const { camera } = useThree();
  const targetPos = useRef(new THREE.Vector3(0, 2, 12));
  const targetLook = useRef(new THREE.Vector3(0, 0, 0));

  useFrame(() => {
    // Determine which segment we're in
    const segments = cameraPath.length - 1;
    const rawIndex = scrollProgress * segments;
    const idx = Math.min(Math.floor(rawIndex), segments - 1);
    const t = rawIndex - idx;

    const from = cameraPath[idx];
    const to = cameraPath[idx + 1] || cameraPath[idx];

    // Smooth interpolation target
    targetPos.current.lerpVectors(from.pos, to.pos, easeInOut(t));
    targetLook.current.lerpVectors(from.target, to.target, easeInOut(t));

    // Add subtle camera sway
    const time = Date.now() * 0.0003;
    const sway = new THREE.Vector3(
      Math.sin(time * 0.7) * 0.15,
      Math.cos(time * 0.5) * 0.08,
      0
    );

    // Damped camera movement
    camera.position.lerp(targetPos.current.clone().add(sway), 0.04);
    const lookTarget = new THREE.Vector3();
    lookTarget.lerp(targetLook.current, 0.04);
    camera.lookAt(targetLook.current);
  });

  return null;
}

function easeInOut(t: number): number {
  return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
}
