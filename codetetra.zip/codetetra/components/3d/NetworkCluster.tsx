'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface NetworkClusterProps {
  scrollProgress: number;
}

function DataParticles({ start, end, color }: { start: THREE.Vector3; end: THREE.Vector3; color: string }) {
  const ref = useRef<THREE.Mesh>(null);
  const speed = useMemo(() => 0.5 + Math.random() * 0.5, []);
  const offset = useMemo(() => Math.random(), []);

  useFrame((state) => {
    if (!ref.current) return;
    const t = ((state.clock.elapsedTime * speed + offset) % 1);
    ref.current.position.lerpVectors(start, end, t);
    ref.current.scale.setScalar(0.5 + Math.sin(t * Math.PI) * 0.5);
  });

  return (
    <mesh ref={ref}>
      <sphereGeometry args={[0.04, 6, 6]} />
      <meshStandardMaterial
        color={color}
        emissive={color}
        emissiveIntensity={2}
        toneMapped={false}
      />
    </mesh>
  );
}

export default function NetworkCluster({ scrollProgress }: NetworkClusterProps) {
  const groupRef = useRef<THREE.Group>(null);

  // Visible from ~45% to ~70% scroll
  const localProgress = Math.max(0, Math.min(1, (scrollProgress - 0.43) / 0.27));
  const visible = scrollProgress > 0.40 && scrollProgress < 0.73;

  const nodeCount = 18;
  const nodes = useMemo(() => {
    return Array.from({ length: nodeCount }, (_, i) => {
      const theta = (i / nodeCount) * Math.PI * 2;
      const radius = 2 + (i % 3) * 1.5;
      const height = (i % 4) * 0.8 - 1.5;
      return new THREE.Vector3(
        Math.cos(theta) * radius,
        height,
        Math.sin(theta) * radius
      );
    });
  }, []);

  const connections = useMemo(() => {
    const conns: [number, number][] = [];
    for (let i = 0; i < nodeCount; i++) {
      // Connect to next 2 neighbors
      conns.push([i, (i + 1) % nodeCount]);
      conns.push([i, (i + 3) % nodeCount]);
    }
    return conns;
  }, []);

  // Line segments geometry
  const lineGeometry = useMemo(() => {
    const points: THREE.Vector3[] = [];
    connections.forEach(([a, b]) => {
      points.push(nodes[a], nodes[b]);
    });
    const geo = new THREE.BufferGeometry().setFromPoints(points);
    return geo;
  }, [connections, nodes]);

  const nodeColors = useMemo(() => {
    const colors = ['#00D4FF', '#0066FF', '#00FF88', '#FF6B00'];
    return nodes.map((_, i) => colors[i % colors.length]);
  }, [nodes]);

  useFrame((state) => {
    if (!groupRef.current) return;
    groupRef.current.rotation.y = state.clock.elapsedTime * 0.08;
    groupRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.05) * 0.1;

    const targetOpacity = visible ? 1 : 0;
    groupRef.current.traverse((child) => {
      if ((child as THREE.Mesh).isMesh || (child as THREE.Line).isLine) {
        const mat = (child as THREE.Mesh).material as THREE.MeshStandardMaterial;
        if (mat) {
          mat.transparent = true;
          mat.opacity = THREE.MathUtils.lerp(mat.opacity ?? 1, targetOpacity, 0.06);
        }
      }
    });
  });

  if (!visible && localProgress <= 0) return null;

  return (
    <group ref={groupRef} position={[0, 0, 0]}>
      {/* Connection lines */}
      <lineSegments geometry={lineGeometry}>
        <lineBasicMaterial
          color="#00D4FF"
          transparent
          opacity={0.15}
        />
      </lineSegments>

      {/* Nodes */}
      {nodes.map((pos, i) => (
        <group key={i} position={pos}>
          {/* Server node */}
          <mesh>
            <boxGeometry args={[0.3, 0.3, 0.3]} />
            <meshStandardMaterial
              color={nodeColors[i]}
              metalness={0.9}
              roughness={0.1}
              emissive={nodeColors[i]}
              emissiveIntensity={0.4}
            />
          </mesh>
          {/* Glow sphere */}
          <mesh>
            <sphereGeometry args={[0.25, 12, 12]} />
            <meshStandardMaterial
              color={nodeColors[i]}
              transparent
              opacity={0.08}
              emissive={nodeColors[i]}
              emissiveIntensity={0.6}
            />
          </mesh>
        </group>
      ))}

      {/* Data flow particles */}
      {connections.slice(0, 20).map(([a, b], i) => (
        <DataParticles
          key={i}
          start={nodes[a]}
          end={nodes[b]}
          color={nodeColors[a]}
        />
      ))}

      {/* Central hub */}
      <mesh>
        <octahedronGeometry args={[0.5]} />
        <meshStandardMaterial
          color="#00D4FF"
          metalness={0.9}
          roughness={0.1}
          emissive="#00D4FF"
          emissiveIntensity={0.6}
          wireframe
        />
      </mesh>
      <mesh>
        <sphereGeometry args={[0.35, 16, 16]} />
        <meshStandardMaterial
          color="#00D4FF"
          transparent
          opacity={0.2}
          emissive="#00D4FF"
          emissiveIntensity={1}
        />
      </mesh>
    </group>
  );
}
