'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface ServerRackProps {
  scrollProgress: number;
}

function ServerUnit({ index, totalUnits }: { index: number; totalUnits: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const lightsRef = useRef<THREE.Group>(null);

  // Random blink interval per unit
  const blinkSpeed = useMemo(() => 0.5 + Math.random() * 3, []);
  const baseColor = useMemo(
    () =>
      ['#00D4FF', '#0066FF', '#00FF88', '#FF6B00'][
        Math.floor(Math.random() * 4)
      ],
    []
  );

  useFrame((state) => {
    if (!lightsRef.current) return;
    const blink = Math.sin(state.clock.elapsedTime * blinkSpeed) > 0;
    lightsRef.current.children.forEach((child, i) => {
      const mat = (child as THREE.Mesh).material as THREE.MeshStandardMaterial;
      if (mat.emissive) {
        mat.emissiveIntensity = (i % 2 === 0 ? blink : !blink) ? 1.5 : 0.2;
      }
    });
  });

  const y = (index / totalUnits) * 6 - 3;

  return (
    <group position={[0, y, 0]}>
      {/* Server chassis */}
      <mesh ref={meshRef} castShadow>
        <boxGeometry args={[3.8, 0.35, 1.2]} />
        <meshStandardMaterial
          color="#0D1117"
          metalness={0.9}
          roughness={0.3}
        />
      </mesh>

      {/* Front panel */}
      <mesh position={[0, 0, 0.61]}>
        <boxGeometry args={[3.8, 0.33, 0.02]} />
        <meshStandardMaterial color="#070B10" metalness={0.8} roughness={0.4} />
      </mesh>

      {/* Drive bays */}
      {[-1.5, -0.9, -0.3, 0.3, 0.9, 1.5].map((x, i) => (
        <mesh key={i} position={[x, 0, 0.62]}>
          <boxGeometry args={[0.4, 0.25, 0.01]} />
          <meshStandardMaterial color="#111820" metalness={0.7} roughness={0.5} />
        </mesh>
      ))}

      {/* Status LEDs */}
      <group ref={lightsRef} position={[1.75, 0, 0.625]}>
        {[0, 1, 2].map((i) => (
          <mesh key={i} position={[0, (i - 1) * 0.07, 0]}>
            <sphereGeometry args={[0.018, 8, 8]} />
            <meshStandardMaterial
              color={baseColor}
              emissive={baseColor}
              emissiveIntensity={1.5}
              toneMapped={false}
            />
          </mesh>
        ))}
      </group>

      {/* GPU indicator bar */}
      <mesh position={[0.2, 0, 0.625]}>
        <boxGeometry args={[1.2, 0.04, 0.005]} />
        <meshStandardMaterial
          color={baseColor}
          emissive={baseColor}
          emissiveIntensity={0.8}
          toneMapped={false}
        />
      </mesh>

      {/* Vent slats on sides */}
      {[-0.15, 0, 0.15].map((z, i) => (
        <mesh key={i} position={[1.92, 0, z]}>
          <boxGeometry args={[0.01, 0.28, 0.15]} />
          <meshStandardMaterial color="#1A2332" metalness={0.9} roughness={0.2} />
        </mesh>
      ))}
    </group>
  );
}

export default function ServerRack({ scrollProgress }: ServerRackProps) {
  const groupRef = useRef<THREE.Group>(null);
  const TOTAL = 12;

  // Visible from ~30% to ~50% scroll
  const localProgress = Math.max(0, Math.min(1, (scrollProgress - 0.28) / 0.22));
  const visible = scrollProgress > 0.25 && scrollProgress < 0.55;

  useFrame((state) => {
    if (!groupRef.current) return;
    groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.15) * 0.3 + localProgress * 0.5;
    groupRef.current.position.x = -2 + localProgress * 0.5;

    const targetOpacity = visible ? 1 : 0;
    groupRef.current.children.forEach((child) => {
      child.traverse((c) => {
        if ((c as THREE.Mesh).isMesh) {
          const mat = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
          if (mat) {
            mat.transparent = true;
            mat.opacity = THREE.MathUtils.lerp(mat.opacity ?? 1, targetOpacity, 0.06);
          }
        }
      });
    });
  });

  if (!visible && localProgress <= 0) return null;

  return (
    <group ref={groupRef} position={[-2, 0, 0]}>
      {/* Rack frame */}
      <mesh>
        <boxGeometry args={[4.2, 6.8, 1.5]} />
        <meshStandardMaterial
          color="#050810"
          metalness={0.95}
          roughness={0.2}
          transparent
          opacity={0.4}
          wireframe
        />
      </mesh>

      {/* Server units */}
      {Array.from({ length: TOTAL }, (_, i) => (
        <ServerUnit key={i} index={i} totalUnits={TOTAL} />
      ))}

      {/* Top/bottom rails */}
      {[-3.2, 3.2].map((y, i) => (
        <mesh key={i} position={[0, y, 0]}>
          <boxGeometry args={[4.2, 0.1, 1.5]} />
          <meshStandardMaterial color="#0D1520" metalness={0.95} roughness={0.2} />
        </mesh>
      ))}

      {/* Cable management */}
      {[-1.8, -0.5, 0.5, 1.8].map((x, i) => (
        <mesh key={i} position={[x, 0, -0.75]} rotation={[0, 0, Math.sin(i) * 0.1]}>
          <cylinderGeometry args={[0.02, 0.02, 6.5, 6]} />
          <meshStandardMaterial
            color={['#00D4FF', '#0066FF', '#FF6B00', '#00FF88'][i]}
            emissive={['#00D4FF', '#0066FF', '#FF6B00', '#00FF88'][i]}
            emissiveIntensity={0.5}
          />
        </mesh>
      ))}
    </group>
  );
}
