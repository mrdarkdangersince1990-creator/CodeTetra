'use client';

import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

interface GPUModelProps {
  scrollProgress: number;
}

// GPU components as primitive geometries
const GPU_PARTS = [
  {
    id: 'die',
    label: 'CUDA Die',
    spec: '16,384 CUDA Cores',
    color: '#00D4FF',
    basePos: [0, 0, 0] as [number, number, number],
    explodeDir: [0, 0, 0] as [number, number, number],
    geo: 'box',
    size: [2.2, 0.15, 1.5],
  },
  {
    id: 'pcb',
    label: 'PCB',
    spec: 'Multi-layer FR4',
    color: '#0D4A2B',
    basePos: [0, -0.2, 0] as [number, number, number],
    explodeDir: [0, -0.8, 0] as [number, number, number],
    geo: 'box',
    size: [3.5, 0.08, 1.8],
  },
  {
    id: 'vram1',
    label: 'HBM3 VRAM',
    spec: '80GB / 3.35TB/s',
    color: '#FF6B00',
    basePos: [-1.0, 0.1, 0.2] as [number, number, number],
    explodeDir: [-1.5, 0.5, 0] as [number, number, number],
    geo: 'box',
    size: [0.5, 0.12, 0.5],
  },
  {
    id: 'vram2',
    label: 'HBM3 VRAM',
    spec: '80GB / 3.35TB/s',
    color: '#FF6B00',
    basePos: [1.0, 0.1, 0.2] as [number, number, number],
    explodeDir: [1.5, 0.5, 0] as [number, number, number],
    geo: 'box',
    size: [0.5, 0.12, 0.5],
  },
  {
    id: 'cooler',
    label: 'Vapor Chamber',
    spec: 'Triple Slot Cooling',
    color: '#8892A4',
    basePos: [0, 0.5, 0] as [number, number, number],
    explodeDir: [0, 1.8, 0] as [number, number, number],
    geo: 'box',
    size: [3.4, 0.4, 1.7],
  },
  {
    id: 'fan1',
    label: 'Triple Fan Array',
    spec: 'PWM 3000RPM',
    color: '#1A2332',
    basePos: [-1.0, 1.1, 0] as [number, number, number],
    explodeDir: [-0.4, 2.8, 0] as [number, number, number],
    geo: 'cylinder',
    size: [0.55, 0.55, 0.12, 16],
  },
  {
    id: 'fan2',
    label: 'Triple Fan Array',
    spec: 'PWM 3000RPM',
    color: '#1A2332',
    basePos: [0, 1.1, 0] as [number, number, number],
    explodeDir: [0, 2.8, 0] as [number, number, number],
    geo: 'cylinder',
    size: [0.55, 0.55, 0.12, 16],
  },
  {
    id: 'fan3',
    label: 'Triple Fan Array',
    spec: 'PWM 3000RPM',
    color: '#1A2332',
    basePos: [1.0, 1.1, 0] as [number, number, number],
    explodeDir: [0.4, 2.8, 0] as [number, number, number],
    geo: 'cylinder',
    size: [0.55, 0.55, 0.12, 16],
  },
  {
    id: 'pcie',
    label: 'PCIe 5.0 x16',
    spec: '128GB/s Bandwidth',
    color: '#FFD700',
    basePos: [0, -0.3, -0.65] as [number, number, number],
    explodeDir: [0, -1.2, -1.2] as [number, number, number],
    geo: 'box',
    size: [2.4, 0.06, 0.2],
  },
  {
    id: 'power',
    label: '16-pin Power',
    spec: '600W TDP Max',
    color: '#FF2D55',
    basePos: [1.6, -0.1, 0.5] as [number, number, number],
    explodeDir: [2.4, 0, 1.0] as [number, number, number],
    geo: 'box',
    size: [0.3, 0.4, 0.25],
  },
];

function GPUPart({
  part,
  explode,
  index,
}: {
  part: typeof GPU_PARTS[0];
  explode: number;
  index: number;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  // Calculate current position based on explode factor
  const currentPos = part.basePos.map((b, i) =>
    b + part.explodeDir[i] * explode
  ) as [number, number, number];

  useFrame((state) => {
    if (!meshRef.current) return;
    // Slow rotation when exploded
    if (explode > 0.1) {
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3 + index) * 0.08;
    }
    // Hover scale
    const targetScale = hovered ? 1.05 : 1;
    meshRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
  });

  return (
    <group position={currentPos}>
      <mesh
        ref={meshRef}
        onPointerEnter={() => setHovered(true)}
        onPointerLeave={() => setHovered(false)}
        castShadow
      >
        {part.geo === 'box' ? (
          <boxGeometry args={part.size as [number, number, number]} />
        ) : (
          <cylinderGeometry args={part.size as [number, number, number, number]} />
        )}
        <meshStandardMaterial
          color={part.color}
          metalness={0.8}
          roughness={0.2}
          emissive={hovered ? part.color : '#000000'}
          emissiveIntensity={hovered ? 0.3 : 0}
        />
      </mesh>

      {/* Edge glow */}
      {hovered && (
        <mesh>
          {part.geo === 'box' ? (
            <boxGeometry args={(part.size as number[]).map((s) => s + 0.04) as [number, number, number]} />
          ) : (
            <cylinderGeometry
              args={[(part.size[0] as number) + 0.04, (part.size[1] as number) + 0.04, (part.size[2] as number) + 0.02, 16]}
            />
          )}
          <meshStandardMaterial
            color={part.color}
            transparent
            opacity={0.15}
            emissive={part.color}
            emissiveIntensity={1}
            wireframe
          />
        </mesh>
      )}

      {/* Info card on hover */}
      {hovered && explode > 0.3 && (
        <Html
          center
          style={{
            pointerEvents: 'none',
            transform: 'translateY(-60px)',
          }}
        >
          <div
            style={{
              background: 'rgba(7,11,16,0.95)',
              border: '1px solid rgba(0,212,255,0.4)',
              padding: '8px 14px',
              whiteSpace: 'nowrap',
              fontFamily: 'Space Mono, monospace',
              backdropFilter: 'blur(8px)',
            }}
          >
            <div style={{ color: '#00D4FF', fontSize: '10px', letterSpacing: '0.15em', marginBottom: '3px' }}>
              {part.label}
            </div>
            <div style={{ color: '#8892A4', fontSize: '9px', letterSpacing: '0.1em' }}>
              {part.spec}
            </div>
          </div>
        </Html>
      )}
    </group>
  );
}

export default function GPUModel({ scrollProgress }: GPUModelProps) {
  const groupRef = useRef<THREE.Group>(null);

  // GPU is visible from ~10% to ~30% scroll
  const localProgress = Math.max(0, Math.min(1, (scrollProgress - 0.08) / 0.22));
  const explode = Math.sin(localProgress * Math.PI) * 1.0;
  const visible = scrollProgress > 0.05 && scrollProgress < 0.38;

  useFrame((state) => {
    if (!groupRef.current) return;
    // Slow continuous rotation
    groupRef.current.rotation.y = state.clock.elapsedTime * 0.12 + localProgress * Math.PI * 0.3;
    groupRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.2) * 0.05;

    // Fade in/out
    const opacity = visible ? 1 : 0;
    groupRef.current.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mat = (child as THREE.Mesh).material as THREE.MeshStandardMaterial;
        if (mat.transparent !== undefined) {
          mat.transparent = true;
          mat.opacity = THREE.MathUtils.lerp(mat.opacity, opacity, 0.05);
        }
      }
    });
  });

  if (!visible && localProgress <= 0) return null;

  return (
    <group ref={groupRef} position={[1.5, 0, 0]} scale={[1.2, 1.2, 1.2]}>
      {GPU_PARTS.map((part, i) => (
        <GPUPart key={part.id + i} part={part} explode={explode} index={i} />
      ))}

      {/* Wireframe overlay for the assembled view */}
      {explode < 0.2 && (
        <mesh>
          <boxGeometry args={[3.6, 1.6, 1.9]} />
          <meshStandardMaterial
            color="#00D4FF"
            transparent
            opacity={0.02}
            wireframe
          />
        </mesh>
      )}
    </group>
  );
}
