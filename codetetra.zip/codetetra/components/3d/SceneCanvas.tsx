'use client';

import { Canvas } from '@react-three/fiber';
import { Suspense, useMemo } from 'react';
import {
  AdaptiveDpr,
  AdaptiveEvents,
  Stars,
  Environment,
} from '@react-three/drei';
import ParticleField from './ParticleField';
import GPUModel from './GPUModel';
import ServerRack from './ServerRack';
import NetworkCluster from './NetworkCluster';
import CameraRig from './CameraRig';

interface SceneCanvasProps {
  scrollProgress: number;
}

export default function SceneCanvas({ scrollProgress }: SceneCanvasProps) {
  return (
    <Canvas
      dpr={[1, 1.5]}
      camera={{ position: [0, 0, 12], fov: 60, near: 0.1, far: 200 }}
      gl={{
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
        toneMapping: 3, // ACESFilmicToneMapping
        toneMappingExposure: 1.2,
      }}
    >
      <AdaptiveDpr pixelated />
      <AdaptiveEvents />

      {/* Lighting */}
      <ambientLight intensity={0.1} />
      <pointLight position={[10, 10, 10]} color="#00D4FF" intensity={2} />
      <pointLight position={[-10, -5, -10]} color="#0066FF" intensity={1.5} />
      <pointLight position={[0, -8, 5]} color="#00FF88" intensity={0.5} />
      <spotLight
        position={[0, 20, 0]}
        angle={0.3}
        penumbra={0.5}
        intensity={3}
        color="#00D4FF"
      />

      <Suspense fallback={null}>
        <CameraRig scrollProgress={scrollProgress} />
        <ParticleField count={2000} />
        <GPUModel scrollProgress={scrollProgress} />
        <ServerRack scrollProgress={scrollProgress} />
        <NetworkCluster scrollProgress={scrollProgress} />
        <Stars
          radius={100}
          depth={60}
          count={1500}
          factor={3}
          saturation={0}
          fade
          speed={0.3}
        />
        <fog attach="fog" args={['#020305', 30, 100]} />
      </Suspense>
    </Canvas>
  );
}
