'use client';

import { useEffect, useState } from 'react';

export default function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('INITIALIZING SYSTEMS');

  const statuses = [
    'INITIALIZING SYSTEMS',
    'LOADING 3D ASSETS',
    'CALIBRATING GPU MATRIX',
    'ESTABLISHING NEURAL LINK',
    'SYSTEM READY',
  ];

  useEffect(() => {
    let p = 0;
    const interval = setInterval(() => {
      p += Math.random() * 18 + 5;
      if (p >= 100) p = 100;
      setProgress(p);
      setStatus(statuses[Math.floor((p / 100) * (statuses.length - 1))]);
      if (p >= 100) clearInterval(interval);
    }, 200);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-[9999] bg-ct-black flex flex-col items-center justify-center">
      {/* Grid bg */}
      <div className="absolute inset-0 bg-grid opacity-30" />

      {/* Center content */}
      <div className="relative z-10 flex flex-col items-center gap-8">
        {/* Logo mark */}
        <div className="relative">
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
            <polygon
              points="40,4 76,62 4,62"
              fill="none"
              stroke="#00D4FF"
              strokeWidth="1.5"
              className="animate-pulse-slow"
            />
            <polygon
              points="40,18 64,56 16,56"
              fill="none"
              stroke="#0066FF"
              strokeWidth="1"
              opacity="0.6"
            />
            <circle cx="40" cy="38" r="4" fill="#00D4FF" />
            {/* Scanning line */}
            <line x1="4" y1="62" x2="76" y2="62" stroke="#00D4FF" strokeWidth="0.5" opacity="0.4" />
          </svg>

          {/* Corner decorators */}
          <div className="absolute -top-2 -left-2 w-3 h-3 border-t border-l border-ct-cyan" />
          <div className="absolute -top-2 -right-2 w-3 h-3 border-t border-r border-ct-cyan" />
          <div className="absolute -bottom-2 -left-2 w-3 h-3 border-b border-l border-ct-cyan" />
          <div className="absolute -bottom-2 -right-2 w-3 h-3 border-b border-r border-ct-cyan" />
        </div>

        {/* Brand */}
        <div className="text-center">
          <div className="font-display text-2xl font-bold text-white tracking-[0.3em]">
            CODE<span className="text-ct-cyan">TETRA</span>
          </div>
          <div className="font-mono text-[10px] text-ct-gray mt-1 tracking-[0.4em]">
            INTELLIGENCE INFRASTRUCTURE
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-64 flex flex-col gap-2">
          <div className="h-px bg-ct-border overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-ct-blue to-ct-cyan transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between items-center">
            <span className="font-mono text-[10px] text-ct-gray tracking-widest">
              {status}
            </span>
            <span className="font-mono text-[10px] text-ct-cyan">
              {Math.floor(progress)}%
            </span>
          </div>
        </div>

        {/* Binary rain effect */}
        <div className="font-mono text-[9px] text-ct-border leading-4 tracking-widest overflow-hidden h-6">
          <div style={{ animation: 'scan 1s linear infinite' }}>
            01001000 01100101 01101100 01101100 01101111
          </div>
        </div>
      </div>
    </div>
  );
}
